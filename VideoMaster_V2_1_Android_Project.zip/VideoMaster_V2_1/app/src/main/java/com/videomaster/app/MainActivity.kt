package com.videomaster.app

import android.app.Activity
import android.content.Context
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.InputMethodManager
import android.widget.*
import androidx.activity.ComponentActivity
import androidx.media3.common.MediaItem
import androidx.media3.common.MimeTypes
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView

private data class ResolvedVideo(
    val mediaUri: Uri,
    val mimeType: String? = null,
    val displayName: String = "Video"
)

private sealed class LinkResult {
    data class Ready(val video: ResolvedVideo) : LinkResult()
    data class NeedsIntegration(val provider: String, val explanation: String) : LinkResult()
    data class Invalid(val explanation: String) : LinkResult()
}

/**
 * Provider integrations belong here.
 *
 * A provider adapter may return a playable media URL only through an official,
 * documented or otherwise authorized integration. Do not scrape private APIs,
 * bypass login/access checks, or defeat DRM.
 */
private interface CloudProviderAdapter {
    fun canHandle(uri: Uri): Boolean
    fun resolve(uri: Uri): LinkResult
}

private class TeraBoxAdapter : CloudProviderAdapter {
    override fun canHandle(uri: Uri) =
        uri.host.orEmpty().lowercase().let { "terabox" in it || "1024tera" in it || "terasharelink.com" in it }

    override fun resolve(uri: Uri) = LinkResult.NeedsIntegration(
        "TeraBox",
        "TeraBox sharing links need an authorized stream integration. This provider adapter is ready to be connected when a supported API or partner method is available."
    )
}

private class DiskwalaAdapter : CloudProviderAdapter {
    override fun canHandle(uri: Uri) = uri.host.orEmpty().lowercase().contains("diskwala")

    override fun resolve(uri: Uri) = LinkResult.NeedsIntegration(
        "Diskwala",
        "Diskwala sharing links need a documented, authorized way to obtain the video stream."
    )
}

private class FlexenAdapter : CloudProviderAdapter {
    override fun canHandle(uri: Uri) = uri.host.orEmpty().lowercase().contains("flexen")

    override fun resolve(uri: Uri) = LinkResult.NeedsIntegration(
        "Flexen",
        "Flexen sharing links need a documented, authorized way to obtain the video stream."
    )
}

private class VideoLinkResolver {
    private val providers: List<CloudProviderAdapter> = listOf(
        TeraBoxAdapter(), DiskwalaAdapter(), FlexenAdapter()
    )

    fun resolve(raw: String): LinkResult {
        val value = raw.trim()
        if (value.isBlank()) return LinkResult.Invalid("Paste a video link first.")

        val uri = try { Uri.parse(value) } catch (_: Exception) { null }
            ?: return LinkResult.Invalid("This link is not valid.")

        if (uri.scheme != "https" && uri.scheme != "http") {
            return LinkResult.Invalid("Only HTTP and HTTPS links are supported.")
        }
        if (uri.host.isNullOrBlank()) {
            return LinkResult.Invalid("The link must contain a valid website address.")
        }

        val adapter = providers.firstOrNull { it.canHandle(uri) }
        if (adapter != null) return adapter.resolve(uri)

        val path = uri.path.orEmpty().lowercase()
        val mime = when {
            path.endsWith(".m3u8") -> MimeTypes.APPLICATION_M3U8
            path.endsWith(".mpd") -> MimeTypes.APPLICATION_MPD
            path.endsWith(".mp4") -> MimeTypes.VIDEO_MP4
            path.endsWith(".webm") -> MimeTypes.VIDEO_WEBM
            else -> null // ExoPlayer can infer some stream types from response/URI.
        }
        return LinkResult.Ready(
            ResolvedVideo(uri, mime, uri.lastPathSegment ?: "Video")
        )
    }
}

class MainActivity : ComponentActivity() {
    private val red = Color.rgb(229, 9, 20)
    private val background = Color.rgb(13, 13, 16)
    private val surface = Color.rgb(35, 35, 42)
    private val resolver = VideoLinkResolver()
    private val prefs by lazy { getSharedPreferences("video_master_v2", Context.MODE_PRIVATE) }

    private var exoPlayer: ExoPlayer? = null
    private lateinit var playerView: PlayerView
    private lateinit var urlInput: EditText
    private lateinit var statusText: TextView
    private lateinit var historyContainer: LinearLayout
    private lateinit var playButton: Button

    private val playbackListener = object : Player.Listener {
        override fun onPlaybackStateChanged(playbackState: Int) {
            when (playbackState) {
                Player.STATE_BUFFERING -> showStatus("Buffering video…")
                Player.STATE_READY -> showStatus("Video ready.")
                Player.STATE_ENDED -> showStatus("Playback finished.")
                Player.STATE_IDLE -> Unit
            }
        }

        override fun onPlayerError(error: PlaybackException) {
            showStatus("Playback failed. Check that this is a direct, accessible media stream.")
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildScreen()
        exoPlayer = ExoPlayer.Builder(this).build().also {
            it.addListener(playbackListener)
            playerView.player = it
        }
        renderHistory()
    }

    private fun buildScreen() {
        val scroll = ScrollView(this).apply { setBackgroundColor(background) }
        val page = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(22), dp(18), dp(28))
        }
        scroll.addView(page)

        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        val logo = TextView(this).apply {
            text = "▶"
            textSize = 23f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            setBackgroundColor(red)
            setPadding(dp(10), dp(5), dp(10), dp(5))
        }
        header.addView(logo)
        val brand = TextView(this).apply {
            text = "  VIDEO MASTER"
            textSize = 23f
            setTextColor(Color.WHITE)
            setTypeface(null, android.graphics.Typeface.BOLD)
        }
        header.addView(brand)
        page.addView(header)

        page.addView(text("YOUR LINKS. YOUR VIDEOS. YOUR PLAYER.", 11f, Color.LTGRAY)
            .apply { setPadding(0, dp(8), 0, dp(25)) })

        page.addView(text("Play from link", 21f, Color.WHITE, true))
        urlInput = EditText(this).apply {
            hint = "Paste MP4, M3U8 or supported cloud link"
            setHintTextColor(Color.LTGRAY)
            setTextColor(Color.WHITE)
            textSize = 14f
            singleLine = true
            inputType = android.text.InputType.TYPE_CLASS_TEXT or
                android.text.InputType.TYPE_TEXT_VARIATION_URI
            setPadding(dp(14), dp(13), dp(14), dp(13))
            setBackgroundColor(surface)
        }
        page.addView(urlInput, matchWrap().apply { topMargin = dp(12) })

        playButton = Button(this).apply {
            text = "▶   PLAY INSIDE VIDEO MASTER"
            setTextColor(Color.WHITE)
            setBackgroundColor(red)
            setOnClickListener { onPlayClicked() }
        }
        page.addView(playButton, matchWrap().apply {
            topMargin = dp(10)
            bottomMargin = dp(14)
        })

        statusText = text("Ready. Paste a supported video link.", 13f, Color.LTGRAY)
        page.addView(statusText)

        playerView = PlayerView(this).apply {
            useController = true
            setShowBuffering(PlayerView.SHOW_BUFFERING_ALWAYS)
            setBackgroundColor(Color.BLACK)
        }
        page.addView(playerView, LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, dp(235)
        ).apply { topMargin = dp(12); bottomMargin = dp(22) })

        page.addView(text("Recently played", 20f, Color.WHITE, true))
        val historyActions = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        historyActions.addView(actionButton("Refresh") { renderHistory() }, weighted())
        historyActions.addView(actionButton("Clear history") {
            prefs.edit().remove("history").apply()
            renderHistory()
            showStatus("Watch history cleared.")
        }, weighted())
        page.addView(historyActions)

        historyContainer = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        page.addView(historyContainer)

        page.addView(text(
            "Cloud sharing links may need a service-approved integration before they can play as streams. Video Master does not bypass passwords, access controls or DRM.",
            12f, Color.LTGRAY
        ).apply { setPadding(0, dp(18), 0, 0) })

        setContentView(scroll)
    }

    private fun onPlayClicked() {
        when (val result = resolver.resolve(urlInput.text.toString())) {
            is LinkResult.Invalid -> showStatus(result.explanation)
            is LinkResult.NeedsIntegration -> {
                stopPlayback()
                showStatus("${result.provider}: ${result.explanation}")
            }
            is LinkResult.Ready -> startPlayback(result.video)
        }
    }

    private fun startPlayback(video: ResolvedVideo) {
        hideKeyboard()
        playButton.isEnabled = false
        showStatus("Connecting to video…")

        val itemBuilder = MediaItem.Builder().setUri(video.mediaUri)
        video.mimeType?.let { itemBuilder.setMimeType(it) }

        try {
            exoPlayer?.apply {
                stop()
                clearMediaItems()
                setMediaItem(itemBuilder.build())
                prepare()
                playWhenReady = true
            } ?: showStatus("Player is not ready. Please restart the app.")
            saveHistory(video.mediaUri.toString())
        } catch (_: Exception) {
            showStatus("This link could not be opened as a video stream.")
        } finally {
            playButton.isEnabled = true
        }
    }

    private fun stopPlayback() {
        exoPlayer?.apply {
            playWhenReady = false
            stop()
            clearMediaItems()
        }
    }

    private fun saveHistory(url: String) {
        val previous = prefs.getString("history", "").orEmpty()
        val entries = (listOf(url) + previous.split("\n")
            .filter { it.isNotBlank() && it != url }).take(10)
        prefs.edit().putString("history", entries.joinToString("\n")).apply()
        renderHistory()
    }

    private fun renderHistory() {
        if (!::historyContainer.isInitialized) return
        historyContainer.removeAllViews()
        val entries = prefs.getString("history", "").orEmpty()
            .split("\n").filter { it.isNotBlank() }

        if (entries.isEmpty()) {
            historyContainer.addView(text("No videos played yet.", 13f, Color.LTGRAY))
            return
        }

        entries.forEach { url ->
            val item = TextView(this).apply {
                text = "▶   ${url.take(72)}"
                textSize = 13f
                setTextColor(Color.WHITE)
                setPadding(dp(10), dp(14), dp(10), dp(14))
                setOnClickListener {
                    urlInput.setText(url)
                    onPlayClicked()
                }
            }
            historyContainer.addView(item)
            historyContainer.addView(View(this).apply {
                setBackgroundColor(Color.DKGRAY)
            }, LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(1)
            ))
        }
    }

    private fun actionButton(title: String, action: () -> Unit) =
        Button(this).apply {
            text = title
            setTextColor(Color.WHITE)
            setBackgroundColor(surface)
            setOnClickListener { action() }
        }

    private fun text(value: String, size: Float, color: Int, bold: Boolean = false) =
        TextView(this).apply {
            text = value
            textSize = size
            setTextColor(color)
            if (bold) setTypeface(null, android.graphics.Typeface.BOLD)
        }

    private fun showStatus(message: String) {
        if (::statusText.isInitialized) statusText.text = message
    }

    private fun hideKeyboard() {
        if (!::urlInput.isInitialized) return
        (getSystemService(Activity.INPUT_METHOD_SERVICE) as InputMethodManager)
            .hideSoftInputFromWindow(urlInput.windowToken, 0)
        urlInput.clearFocus()
    }

    private fun matchWrap() = LinearLayout.LayoutParams(
        ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
    )

    private fun weighted() = LinearLayout.LayoutParams(0, dp(48), 1f).apply {
        marginEnd = dp(5)
    }

    private fun dp(value: Int) =
        (value * resources.displayMetrics.density).toInt()

    override fun onStop() {
        super.onStop()
        exoPlayer?.pause()
    }

    override fun onDestroy() {
        playerView.player = null
        exoPlayer?.removeListener(playbackListener)
        exoPlayer?.release()
        exoPlayer = null
        super.onDestroy()
    }
}
