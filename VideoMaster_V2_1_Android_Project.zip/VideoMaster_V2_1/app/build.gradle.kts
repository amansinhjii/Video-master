plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.videomaster.app"
    compileSdk = 36

    defaultConfig {
        applicationId = "com.videomaster.app"
        minSdk = 23
        targetSdk = 36
        versionCode = 3
        versionName = "2.1"
    }
}

dependencies {
    implementation("androidx.activity:activity-ktx:1.11.0")
    implementation("androidx.media3:media3-exoplayer:1.11.1")
    implementation("androidx.media3:media3-ui:1.11.1")
}
