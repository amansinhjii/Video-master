# Video Master V2 — Android starter

## What's new in V2
- Clear in-app playback flow for direct media links.
- Direct MP4, HLS (`.m3u8`) and DASH (`.mpd`) MIME hints.
- Provider adapter architecture for TeraBox, Diskwala and Flexen.
- Honest unsupported-provider messages instead of treating share pages as video streams.
- Fixed player listener lifecycle; playback errors are surfaced in the UI.
- Local recent-link history.

## Current support
Direct, publicly accessible HTTP/HTTPS media streams are the working playback target. A cloud share page is often HTML, not a stream URL. Provider adapters are intentionally placeholders until an official/documented/authorized integration is available. No private endpoint scraping, authentication bypass, or DRM circumvention is implemented.

## Open and run
1. Extract this ZIP.
2. Open the `VideoMaster_V2` folder in Android Studio.
3. Use JDK 17 and let Gradle sync.
4. Connect an Android device with USB debugging enabled, or use an emulator.
5. Press Run.

## Build APK
Android Studio > Build > Build Bundle(s) / APK(s) > Build APK(s).

Debug APK output is normally:
`app/build/outputs/apk/debug/app-debug.apk`

## Test link
Use a direct MP4/HLS stream URL that you own or are authorized to access. A public sample MP4 can be used for a basic smoke test.

## Next integration requirement
For each cloud provider, we need its official API/SDK documentation, a partner integration, or another documented permitted method that returns a playable media URL and any required short-lived headers/tokens. Do not share passwords, cookies, or private account tokens in chat.


## V2.1 update — terasharelink.com
- Recognizes `terasharelink.com` as a TeraBox-related share-link domain.
- Routes it to the TeraBox provider adapter instead of mistakenly treating it as a direct MP4/HLS URL.
- This is link classification only. Actual cloud playback still requires a configured, authorized TeraBox Open Platform integration and secure backend credentials.
